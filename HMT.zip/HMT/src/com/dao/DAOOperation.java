package com.dao;

import com.model.User;

public interface DAOOperation {

	public String authenticateUser(User user);
	public String registerUser(User user) throws Exception;
	public String changePassword(User user) throws Exception;
	
}
